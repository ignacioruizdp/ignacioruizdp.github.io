export type BlockMessages = {
  collapse: string;
  expand: string;
  loading: string;
  options: string;
};

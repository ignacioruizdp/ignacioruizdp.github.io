export type DialogMessages = {
  close: string;
  resizeEnabled: string;
  dragEnabled: string;
};
